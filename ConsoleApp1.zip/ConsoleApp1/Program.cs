﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ArrayList list = new ArrayList();
                list.Add(4.5);
                list.Add(18);
                list.AddRange(new string[] { "Студент", "Петров" });
                ArrayList list1 = new ArrayList();
                list1.Add(4.5);
                list1.Add(18);
                list1.AddRange(new string[] { "Студент", "Иванов" });
                Console.WriteLine("Введите с какой позиции нужно вставить новую коллекцию:");
                int n = int.Parse(Console.ReadLine());
                if (!(n < 0) || n > list.Count)
                {
                    list.InsertRange(n, list1);

                    foreach (object e in list)
                    {
                        Console.WriteLine(e);
                    }
                    n = n / 2;
                    Console.WriteLine("Введите какое кол-во эл нужно удалить:");
                    int k = int.Parse(Console.ReadLine());
                    if (!(k > list.Count - n || k < 1))
                    {

                        list.RemoveRange(n, k);

                        foreach (object e in list)
                        {
                            Console.WriteLine(e);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Кол-во чисел > чем в позиции n/2, либо меньше 1");
                    }
                }
                else
                {
                    Console.WriteLine("Значение либо менбше 0,либо больше размера коллекции");

                }
            }
            catch
            {
                Console.WriteLine("Начните сначала");
            }




            Console.ReadLine();
        }
    }
}
